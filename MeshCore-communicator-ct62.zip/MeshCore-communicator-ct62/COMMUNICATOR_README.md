# LoRa Communicator - MeshCore firmware (HT-CT62 + TCA8418 keyboard + SSD1306 OLED)

> Status: written but **not yet compiled or tested on hardware**. Expect small fixes on the first build.

This is the official MeshCore *companion radio (BLE)* firmware with an added hardware keyboard UI.
Nothing in the original MeshCore code was removed; the communicator adds new files only:

| File | Purpose |
|------|---------|
| `variants/communicator_ct62/` | Board definition (pins, radio, display, build environment) |
| `src/helpers/ui/TCA8418Keyboard.h` | TCA8418 keyboard driver + key map |
| `examples/companion_radio/ui-keyboard/` | UI with a Chat screen (pick recipient, type, send) |
| `tools/img2c.py`, `graphics/` | Tools and files for your own graphics |

## 1. Build and upload (VS Code + PlatformIO)

1. Install **VS Code** and the **PlatformIO IDE** extension.
2. `File -> Open Folder` and select this project folder.
3. Connect the board over USB-C and click **Upload** (arrow icon in the bottom status bar).
   The environment `Communicator_ct62_companion_radio_ble` is the default (see `platformio.local.ini`).
   The first build takes a few minutes while PlatformIO downloads the toolchain and libraries.
4. Command-line alternative: `pio run -e Communicator_ct62_companion_radio_ble -t upload`

If the build fails, copy the last lines of the error output - they usually point straight at the problem.

## 2. Connect your phone

Open the MeshCore app -> Bluetooth -> choose `MeshCore-<name>` -> PIN **123456**
(change it with `BLE_PIN_CODE` in `variants/communicator_ct62/platformio.ini`).

## 3. Wiring

- I2C bus (shared): SDA = GPIO0, SCL = GPIO1
  - SSD1306 OLED at address `0x3C`
  - TCA8418 keyboard controller at address `0x34`
- TCA8418: ROW0..ROW4 = matrix rows, COL0..COL9 = matrix columns.
  Diode **cathode on the column side** (as in your schematic).
- TCA8418 `INT` is optional. Without it the keyboard is polled every 10 ms.
  If you wire it, set `KB_INT_PIN` to that GPIO in `variants/communicator_ct62/platformio.ini`.
- Note: your schematic has 50 switches (SW1..SW59 with gaps) but the BOM lists 45 switches and 45 diodes - check the BOM.

## 4. Keyboard layout (5 rows x 10 columns)

| | C0 | C1 | C2 | C3 | C4 | C5 | C6 | C7 | C8 | C9 |
|--|--|--|--|--|--|--|--|--|--|--|
| R0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 0 |
| R1 | Q | W | E | R | T | Y | U | I | O | P |
| R2 | A | S | D | F | G | H | J | K | L | BKSP |
| R3 | SHIFT | Z | X | C | V | B | N | M | , | . |
| R4 | SYM | FN | ESC | MENU | SPACE | LEFT | UP | DOWN | RIGHT | ENTER |

- **SHIFT**: tap = one capital letter, double tap = CAPS LOCK, tap again = off. Shift + digit = `! @ # $ % ^ & * ( )`.
  Shift + `,` = `!`, Shift + `.` = `?`.
- **SYM** (tap for one symbol, or hold):
  - R1: `" ' ` ~ | \ < > { }`
  - R2: `- _ + = / : ; [ ]`
  - R3: `? ! " ' : ; / < >`
- **FN**: right after a letter, cycles through accented variants
  (a -> á -> ä, e -> é -> ě, o -> ó -> ô -> ö, u -> ú -> ů -> ü, c -> č, s -> š, z -> ž, l -> ľ -> ĺ, n -> ň, d -> ď, t -> ť, r -> ř -> ŕ, y -> ý, i -> í).
  The OLED cannot draw accented characters (they show as blocks); the phone app and the recipient see them correctly.
- **MENU**: opens / closes the Chat screen.  **ESC**: back.

## 5. Using it

- Home screen: LEFT / RIGHT switch pages (recent adverts, radio, Bluetooth, advert, shutdown).
  ENTER activates the page action (toggle Bluetooth, send advert, shut down).
- **MENU -> Chat**: UP / DOWN choose a channel (`#`) or contact (`@`), ENTER opens the compose view,
  type the message (max 120 characters), ENTER sends, ESC goes back to the list.
- Contacts and channels are managed from the phone app; the keyboard only sends to ones that already exist.
- Delivery confirmations (ACK) for direct messages are not shown on the OLED yet. Channel messages work normally.

## 6. Custom graphics (boot screen and icons)

Everything goes into ONE file: `examples/companion_radio/ui-keyboard/custom_graphics.h`.

1. Convert your picture (OLED is 128x64, black/white only):
   ```bash
   pip install pillow
   python3 tools/img2c.py my_picture.png -W 128 -H 64 --name custom_splash --preview preview.png
   ```
2. Copy the code it prints into `custom_graphics.h`, replacing the sample array between the two `PASTE` lines.
3. Upload again. The picture is shown for 3 seconds at power-up.

| Option | Effect |
|--------|--------|
| `--invert` | swap black and white |
| `--dither` | dithering, better for photos and gradients |
| `--threshold N` | black/white cut-off, 0-255 (default 128) |
| `--preview file.png` | writes a 4x preview so you can check how it will look |

Set `USE_CUSTOM_SPLASH` to `0` in that file to show the MeshCore logo again. The small icons (Bluetooth,
advert, power, muted) can be replaced in `icons.h` - see `graphics/README.md` for names and sizes.

## 7. Hardware test before the full firmware

The separate `communicator_test` Arduino sketch checks I2C, the OLED and every key. Run it first if the
firmware shows a blank screen or dead keys.
