#pragma once

// Header-only driver for a TCA8418 keypad scanner (I2C 0x34) + keymap for the
// 5 rows x 10 columns LoRa communicator keyboard.
//
//   TCA8418 pins:  ROW0..ROW4  -> matrix rows 0..4
//                  COL0..COL9  -> matrix columns 0..9
//   Diodes: one per key (the TCA8418 drives columns low, rows are inputs with pull-ups,
//           so the diode CATHODE must be on the COLUMN side).
//
// Physical layout (row 0 = top):
//
//   R0:  1    2    3    4    5    6    7    8    9    0
//   R1:  Q    W    E    R    T    Y    U    I    O    P
//   R2:  A    S    D    F    G    H    J    K    L    BKSP
//   R3:  SHFT Z    X    C    V    B    N    M    ,    .
//   R4:  SYM  FN   ESC  MENU SPC  LEFT UP   DOWN RIGHT ENTER
//
//   SHIFT: tap = one capital letter, double tap = CAPS LOCK, tap again = off. Can also be held.
//          Shift + digit = ! @ # $ % ^ & * ( )      Shift + ,  = !      Shift + .  = ?
//   SYM:   tap (one-shot) or hold. Punctuation on the letter keys (see KM_SYM below).
//   FN:    "diacritic cycle" - press right after a letter to cycle a -> á -> ä -> a, c -> č ...
//          (needed for Slovak/Czech text; handled by the compose screen)
//   MENU:  toggles Home <-> Chat screen.

#include <Arduino.h>
#include <Wire.h>

#ifndef KB_I2C_ADDR
  #define KB_I2C_ADDR        0x34
#endif
#define KB_ROWS              5
#define KB_COLS              10

// codes emitted by the keyboard (printable ASCII is emitted as-is)
#define KB_BACKSPACE         8
#define KB_TAB               9
#define KB_DIACRITIC         0xF4     // FN key
// KEY_ENTER (13), KEY_CANCEL (27), KEY_LEFT/UP/DOWN/RIGHT (0xB4..0xB7) and KEY_HOME (0xF0)
// come from helpers/ui/UIScreen.h - values duplicated here so this header stands alone.
#ifndef KEY_ENTER
  #define KEY_LEFT           0xB4
  #define KEY_UP             0xB5
  #define KEY_DOWN           0xB6
  #define KEY_RIGHT          0xB7
  #define KEY_ENTER            13
  #define KEY_CANCEL           27
  #define KEY_HOME           0xF0
#endif

// internal marker codes for modifier keys inside the keymap tables
#define KM_NONE   0
#define KM_SHIFT  1
#define KM_SYM    2

// ---- keymap tables [row][col] ------------------------------------------------------------
static const uint8_t KM_BASE[KB_ROWS][KB_COLS] = {
  { '1','2','3','4','5','6','7','8','9','0' },
  { 'q','w','e','r','t','y','u','i','o','p' },
  { 'a','s','d','f','g','h','j','k','l', KB_BACKSPACE },
  { KM_SHIFT,'z','x','c','v','b','n','m',',','.' },
  { KM_SYM, KB_DIACRITIC, KEY_CANCEL, KEY_HOME, ' ', KEY_LEFT, KEY_UP, KEY_DOWN, KEY_RIGHT, KEY_ENTER },
};

// used with SHIFT (letters are simply upper-cased in code, only non-letters need a table)
static const uint8_t KM_SHIFTED[KB_ROWS][KB_COLS] = {
  { '!','@','#','$','%','^','&','*','(',')' },
  { 0,0,0,0,0,0,0,0,0,0 },
  { 0,0,0,0,0,0,0,0,0,0 },
  { 0,0,0,0,0,0,0,0,'!','?' },
  { 0,0,0,0,0,0,0,0,0,0 },
};

// used with SYM
static const uint8_t KM_SYMBOLS[KB_ROWS][KB_COLS] = {
  { '!','@','#','$','%','^','&','*','(',')' },
  { '"','\'','`','~','|','\\','<','>','{','}' },
  { '-','_','+','=','/',':',';','[',']', 0 },
  { 0,'?','!','"','\'',':',';','/','<','>' },
  { 0,0,0,0,0,0,0,0,0,0 },
};

class TCA8418Keyboard {
  // registers
  enum : uint8_t {
    REG_CFG = 0x01, REG_INT_STAT = 0x02, REG_KEY_LCK_EC = 0x03, REG_KEY_EVENT_A = 0x04,
    REG_KP_GPIO1 = 0x1D, REG_KP_GPIO2 = 0x1E, REG_KP_GPIO3 = 0x1F,
  };

  TwoWire* _wire = nullptr;
  int _int_pin = -1;
  bool _ok = false;
  unsigned long _next_poll = 0;

  // modifier state
  bool shift_held = false, shift_used = false, shift_latch = false, caps = false;
  bool sym_held = false, sym_used = false, sym_latch = false;
  unsigned long last_shift_tap = 0;

  // small queue of decoded characters
  uint8_t q[8];
  uint8_t qh = 0, qt = 0;
  void push(uint8_t c) { uint8_t n = (qt + 1) & 7; if (n != qh) { q[qt] = c; qt = n; } }

  bool writeReg(uint8_t reg, uint8_t val) {
    _wire->beginTransmission(KB_I2C_ADDR);
    _wire->write(reg);
    _wire->write(val);
    return _wire->endTransmission() == 0;
  }
  int readReg(uint8_t reg) {
    _wire->beginTransmission(KB_I2C_ADDR);
    _wire->write(reg);
    if (_wire->endTransmission(false) != 0) return -1;
    if (_wire->requestFrom((uint8_t)KB_I2C_ADDR, (uint8_t)1) != 1) return -1;
    return _wire->read();
  }

  void handleEvent(uint8_t raw) {
    bool pressed = raw & 0x80;
    int k = (raw & 0x7F) - 1;             // key number = row*10 + col  (0..79)
    if (k < 0) return;
    int row = k / 10, col = k % 10;
    if (row >= KB_ROWS || col >= KB_COLS) return;
    uint8_t base = KM_BASE[row][col];
    unsigned long now = millis();

    if (base == KM_SHIFT) {
      if (pressed) { shift_held = true; shift_used = false; }
      else {
        shift_held = false;
        if (!shift_used) {                // a clean tap
          if (caps) { caps = false; shift_latch = false; }
          else if (shift_latch && now - last_shift_tap < 400) { caps = true; shift_latch = false; }
          else shift_latch = true;
          last_shift_tap = now;
        }
      }
      return;
    }
    if (base == KM_SYM) {
      if (pressed) { sym_held = true; sym_used = false; }
      else {
        sym_held = false;
        if (!sym_used) sym_latch = !sym_latch;
      }
      return;
    }
    if (!pressed) return;                 // only key-down produces characters

    bool shift = shift_held || shift_latch;
    bool sym = sym_held || sym_latch;
    uint8_t out = base;

    if (sym && KM_SYMBOLS[row][col]) {
      out = KM_SYMBOLS[row][col];
    } else if (shift && KM_SHIFTED[row][col]) {
      out = KM_SHIFTED[row][col];
    } else if (base >= 'a' && base <= 'z') {
      if (shift || caps) out = base - 32;
    }
    // consume one-shot modifiers
    if (shift_held) shift_used = true;
    if (sym_held) sym_used = true;
    shift_latch = false;
    sym_latch = false;
    push(out);
  }

  void drain() {
    int ec = readReg(REG_KEY_LCK_EC);
    if (ec < 0) return;
    int n = ec & 0x0F;
    while (n-- > 0) {
      int ev = readReg(REG_KEY_EVENT_A);
      if (ev <= 0) break;
      handleEvent((uint8_t)ev);
    }
    writeReg(REG_INT_STAT, 0x01);         // clear key-event interrupt flag
  }

public:
  // int_pin: TCA8418 INT output (active low) or -1 to simply poll every 10 ms
  bool begin(TwoWire& wire, int int_pin = -1) {
    _wire = &wire;
    _int_pin = int_pin;
    _wire->beginTransmission(KB_I2C_ADDR);
    if (_wire->endTransmission() != 0) { _ok = false; return false; }   // chip not answering
    writeReg(REG_KP_GPIO1, 0x1F);         // ROW0..ROW4 = keypad
    writeReg(REG_KP_GPIO2, 0xFF);         // COL0..COL7 = keypad
    writeReg(REG_KP_GPIO3, 0x03);         // COL8..COL9 = keypad
    writeReg(REG_CFG, 0x01 | 0x20);       // KE_IEN + overflow mode: FIFO overwrites oldest
    writeReg(REG_INT_STAT, 0x1F);         // clear all flags
    if (_int_pin >= 0) pinMode(_int_pin, INPUT_PULLUP);
    // flush stale events
    for (int i = 0; i < 16; i++) { if (readReg(REG_KEY_EVENT_A) <= 0) break; }
    _ok = true;
    return true;
  }

  bool isPresent() const { return _ok; }

  // returns next character / key code, or 0 when nothing is pending
  uint8_t poll() {
    if (!_ok) return 0;
    if (qh == qt) {
      unsigned long now = millis();
      if (_int_pin >= 0) {
        if (digitalRead(_int_pin) == LOW) drain();
      } else if (now >= _next_poll) {
        _next_poll = now + 10;
        drain();
      }
    }
    if (qh == qt) return 0;
    uint8_t c = q[qh];
    qh = (qh + 1) & 7;
    return c;
  }

  bool capsLock() const { return caps; }
  bool shiftActive() const { return shift_held || shift_latch; }
  bool symActive() const { return sym_held || sym_latch; }
};
